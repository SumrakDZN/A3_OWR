/*	Addon description	*/
class CfgPatches {
	// Avoid confusing users by keeping class name match the PBO name and path.
	class Test_Tank_01 {
		// List addons defining config classes you want to use, define new vehicles available in editor and weapon classes
		requiredAddons[] = {"A3_Armor_F_Beta"};
		units[] = {"O_Test_Tank_01"};
		weapons[] = {};
	};
};
