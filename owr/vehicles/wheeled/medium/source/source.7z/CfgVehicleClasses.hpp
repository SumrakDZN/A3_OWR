/*	Editor Categories	*/
class CfgVehicleClasses {
	// Add new editor category classes only if really required.
	class BIS_Tutorial {
		// Provide display name for your editor category.
		displayName = "BIS Tutorial";
	};
};
