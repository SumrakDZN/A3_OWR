/*	Factions	*/
class CfgFactionClasses {
	// Add new faction classes only if really required.
	class BIS_Tutorial {
		// Provide display name for your faction.
		displayName = "BIS Tutorial";
		priority = 2;
		icon =	"\A3\armor_f_gamma\MBT_02\Data\UI\map_MBT_02_ca.paa";
	};
};
